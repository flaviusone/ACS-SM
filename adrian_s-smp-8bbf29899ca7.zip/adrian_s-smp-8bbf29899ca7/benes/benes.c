#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

uint8_t compute_addr1(int size, uint8_t addr){
	if(addr & 0x01){
		addr |= 1<<size;
	}
	return addr>>1;
}

uint8_t compute_benes_addr1(int size, uint8_t addr){
	uint8_t net_mask = 0xFF << size;
	uint8_t net_addr = addr & net_mask;
	uint8_t loc_addr = addr & (~net_mask);
	return net_addr | compute_addr1(size, loc_addr);
}

uint8_t compute_addr2(int size, uint8_t addr){
	addr <<= 1;

	if(addr & 1<<size){
		addr ^= (1<<size);
		addr |= 1;
	}
	return addr;
}

uint8_t compute_benes_addr2(int size, uint8_t addr){
	uint8_t net_mask = 0xFF << size;
	uint8_t net_addr = addr & net_mask;
	uint8_t loc_addr = addr & (~net_mask);
	return net_addr | compute_addr2(size, loc_addr);
}

int compute_benes_path(uint8_t* path, uint8_t src_addr, int verbosity){
	int i, j = 0;
	uint8_t current_addr;

	current_addr = src_addr;

	for(i = 4; i != 1; --i){
		if(verbosity){printf("intru cu addr %d\n", current_addr);}
		if(verbosity){printf("-- SWITCH #%d\n", j);}
		current_addr ^= path[j];
		if(verbosity){printf("-- cuplez %s\n", path[j]? "invers": "direct");}
		if(verbosity){printf("ies cu addr %d\n", current_addr);}
		current_addr  = compute_benes_addr1(i, current_addr);
		if(verbosity){printf("dupa shuffle %d\n", current_addr);}
		++j;
	}

	for(i = 2; i < 5; ++i){
		if(verbosity){printf("intru cu addr %d\n", current_addr);}
		if(verbosity){printf("-- SWITCH #%d\n", j);}
		current_addr ^= path[j];
		if(verbosity){printf("-- cuplez %s\n", path[j]? "invers": "direct");}
		if(verbosity){printf("ies cu addr %d\n", current_addr);}
		current_addr  = compute_benes_addr2(i, current_addr);
		if(verbosity){printf("dupa shuffle %d\n", current_addr);}
		++j;
	}
	if(verbosity){printf("intru cu addr %d\n", current_addr);}
	if(verbosity){printf("-- SWITCH #%d\n", j);}
	current_addr ^=path[j];
	if(verbosity){printf("-- cuplez %s\n", path[j]? "invers": "direct");}
	if(verbosity){printf("ies cu addr %d\n", current_addr);}

	return current_addr;	
}

int main(){
	uint8_t i, path[128];
	uint8_t src_addr, dst_addr;

	printf("src: ");
	scanf("%d", &src_addr);
	printf("dst: ");
	scanf("%d", &dst_addr);

	while( 1 ){
		for(i = 0; i < 16; ++i){
			path[i]=rand() % 2;
		}

		if(compute_benes_path(path, src_addr, 0) == dst_addr){
			goto end;
		}
	}
end:	
	compute_benes_path(path, src_addr, 1);
	return 0;
}
